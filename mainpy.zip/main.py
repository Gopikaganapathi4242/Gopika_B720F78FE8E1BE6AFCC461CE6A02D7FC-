def Hello_world():
  print("Hello world")

Hello_world()